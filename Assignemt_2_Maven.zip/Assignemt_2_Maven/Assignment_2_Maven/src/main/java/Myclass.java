
public class Myclass {


	public String Sample() {
		
		return "sample";
	}
	
}
