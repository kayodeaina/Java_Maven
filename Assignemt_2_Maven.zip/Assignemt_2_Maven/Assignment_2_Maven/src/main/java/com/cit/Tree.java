/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */
package com.cit;

import java.io.File;
import java.util.ArrayList;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Tree {

	public static ArrayList<Node> fourStarList = new ArrayList<Node>();
	public static ArrayList<Node> fiveStarList = new ArrayList<Node>();
	public static ArrayList<Node> sixStarList = new ArrayList<Node>();

	Node root;
	public void addNode(int key, String name, String prize) {
		
		// Create a new Node and initialise it
		Node newNode = new Node(key, name, prize);

		Tree.fourStarPrizes(newNode);
		Tree.fiveStarPrizes(newNode);
		Tree.sixStarPrizes(newNode);

		// If there is no root this becomes root
		if (root == null) {
			root = newNode;
		} else {
			// Set root as the Node we will start
			// with as we traverse the tree
			Node focusNode = root;

			// Future parent for our new Node
			Node parent;
			while (true) {
				// root is the top parent so we start
				// there
				parent = focusNode;
				// Check if the new node should go on
				// the left side of the parent node
				if (key < focusNode.myKey) {
					// Switch focus to the left child
					focusNode = focusNode.leftChild;
					// If the left child has no children
					if (focusNode == null) {
						// then place the new node on the left of it
						parent.leftChild = newNode;
						return; // All Done
					}
				} else { // If we get here put the node on the right
					focusNode = focusNode.rightChild;
					// If the right child has no children
					if (focusNode == null) {
						// then place the new node on the right of it
						parent.rightChild = newNode;
						return; // All Done
					}
				}
			}
		}
	}

	public static ArrayList<Node> fourStarPrizes(Node focusNode) {

		if (focusNode != null) {
			if(focusNode.myKey == 4)
			{
				// Traverse the left node
				fourStarPrizes(focusNode.leftChild);
				// Visit the currently focused on node
				fourStarList.add(focusNode);
				// Traverse the right node
				fourStarPrizes(focusNode.rightChild);
			}
		}

		return fourStarList;
	}

	public static ArrayList<Node> fiveStarPrizes(Node focusNode) {

		if (focusNode != null) {
			if(focusNode.myKey == 5)
			{
				// Traverse the left node
				fiveStarPrizes(focusNode.leftChild);
				// Visit the currently focused on node
				fiveStarList.add(focusNode);
				// Traverse the right node
				fiveStarPrizes(focusNode.rightChild);
			}
		}
		return fiveStarList;
	}

	public static ArrayList<Node> sixStarPrizes(Node focusNode) {

		if (focusNode != null) {
			if(focusNode.myKey == 6)
			{
				// Traverse the left node
				sixStarPrizes(focusNode.leftChild);
				// Visit the currently focused on node
				sixStarList.add(focusNode);
				// Traverse the right node
				sixStarPrizes(focusNode.rightChild);
			}
		}
		return sixStarList;
	}

	public String getName(int i, ArrayList<Node> name){

		return name.get(i).myName;
	}

	public String getPrize(int i, ArrayList<Node> prize){

		return prize.get(i).myPrize;
	}
	
	File file = new File("WinningPrize.txt");

	public void readFile(){


		try {

			Scanner keyboard = new Scanner(file);
			String line = null;
			while(keyboard.hasNext()){
				line = keyboard.nextLine();
				String[] string = line.split(":");

				if(string[0].equals("4")) {
					addNode(4, string[1], string[2]);
				}
				else if(string[0].equals("5")) {
					addNode(5, string[1], string[2]);
				}

				else if(string[0].equals("6")) {
					addNode(6, string[1], string[2]);
				}

			}

			keyboard.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	class Node {

		int myKey;
		String myName;
		String myPrize;

		Node leftChild;
		Node rightChild;

		Node(int key, String name, String prize) {
			this.myKey = key;
			this.myName = name;
			this.myPrize = prize;
		}
	}
}