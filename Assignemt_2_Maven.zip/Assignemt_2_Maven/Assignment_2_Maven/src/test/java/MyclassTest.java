import org.junit.Test;

public class MyclassTest {

	@Test
	public void test() {
		//fail("Not yet implemented");
	}

}
