package com.cit;

import static org.junit.Assert.*;

import org.junit.Test;

public class GetMyPrizeTreeTest {

	@Test
	public void test() {
		Tree test = new Tree();
		test.readFile();
		String output = test.getPrize(0, Tree.fourStarList);
		assertEquals("200", output);
		
	}

}
