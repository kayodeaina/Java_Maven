package application;
/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
import application.AlertBox;
import javafx.geometry.Insets;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import com.cit.Tree;

public class prize extends Tab{

	Stage window;
	Scene scene;


	int WinningPrize = Guessing_game.WinningPrize;
	ArrayList<Button> btnArrayList = new ArrayList<Button>();

	//	************************************************
	//	Constructor for Prize 
	//  ************************************************	

	public prize() {

		BorderPane bp= new BorderPane();
		VBox vb = new VBox(5);
		vb.setPadding(new Insets(10));

		HBox hb = new HBox(5);
		hb.setPadding(new Insets(10));
		setText("Prize");
		Label lbl = new Label("Select prize");
		//*********************************************************************
		//   Initialise the text file with hashmap and assigning it to the
		//   different prize value option as new
		//************************************************************************	

		File MyPrizeFile = new File("WinningPrize.txt");
//		HashMap<String, String> Four_Star = new HashMap<String, String>();
//		HashMap<String, String> Five_Star = new HashMap<String, String>();
//		HashMap<String, String> Six_Star = new HashMap<String, String>();

		//**********************************************************************
		//  Initialise the scanner, and read in the text file. 
		//  Get the next Line from the text file and store it relevant hashmap.	
		//**********************************************************************	

		Tree myTree = new Tree();
		
		try {
			Scanner keyboard = new Scanner(MyPrizeFile);
			String line = null;
			while(keyboard.hasNext())
			{line = keyboard.nextLine();
			String[] PrizeValue = line.split(":");

			//*********************************************************************
			//  Compare the first value and the Prize option. And put the two values
			//  in the hashmap. 			
			//*********************************************************************			

			if(PrizeValue[0].equals("4")) {
				//Four_Star.put(PrizeValue[1], PrizeValue[2]);
				myTree.addNode(4, PrizeValue[1], PrizeValue[2]);
			}

			else if(PrizeValue[0].equals("5")) {
				//Five_Star.put(PrizeValue[1], PrizeValue[2]);
				myTree.addNode(5, PrizeValue[1], PrizeValue[2]);
			}

			else if(PrizeValue[0].equals("6")) {
				//Six_Star.put(PrizeValue[1], PrizeValue[2]);
				myTree.addNode(6, PrizeValue[1], PrizeValue[2]);
			}
			}

			//*********************************************************************
			//  Depending on the winning prize it will show all the prize options
			//	for that star prize.	
			//*********************************************************************		

			if(WinningPrize == 4){  
				for(int playLoop = 0; playLoop < 4; playLoop++)
				{
					final int n = playLoop;

					//***********************************************************************
					//	Create a new button and assign the value of the hashmap to it.
					//  Then add all the buttons you create to the hbox.				
					//***********************************************************************				

					Button prizeButton = new Button();
					prizeButton.setText(myTree.getName(playLoop, Tree.fourList));

					btnArrayList.add(prizeButton);
					hb.getChildren().add(prizeButton);

					//***************************************************************************
					//	Whatever button you press it will show the prize that you won.			
					//***************************************************************************

					prizeButton.setOnAction((ActionEvent) ->{
						AlertBox.display("You Won!", myTree.getPrize(n, Tree.fourList));

						for(int playLoop_2 = 0; playLoop_2 < 4; playLoop_2++){
							btnArrayList.get(playLoop_2).setDisable(true);
						}
					});
				}
			}

			else if(WinningPrize == 5){
				for(int playLoop = 0; playLoop < 4; playLoop++)
				{
					final int n = playLoop;

					Button prizeButton = new Button();
					prizeButton.setText(myTree.getName(playLoop, Tree.fiveList));

					btnArrayList.add(prizeButton);

					prizeButton.setOnAction((ActionEvent) ->{
						AlertBox.display("You Won!", myTree.getPrize(n, Tree.fiveList));

						for(int playLoop_2 = 0; playLoop_2 < 4; playLoop_2++){
							btnArrayList.get(playLoop_2).setDisable(true);
						}
					});

					hb.getChildren().add(prizeButton);
				}
			}

			else if(WinningPrize == 6){
				for(int playLoop = 0; playLoop < 4; playLoop++)
				{ final int n = playLoop;

				Button prizeButton = new Button();
				prizeButton.setText(myTree.getName(playLoop, Tree.sixList));
				btnArrayList.add(prizeButton);

				prizeButton.setOnAction((ActionEvent) ->{AlertBox.display("You Won!", myTree.getPrize(n, Tree.sixList));

				for(int playLoop_2 = 0; playLoop_2 < 4; playLoop_2++){btnArrayList.get(playLoop_2).setDisable(true);}});
				// selected price
				hb.getChildren().add(prizeButton);}
				keyboard.close();}

		}catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		vb.getChildren().addAll(lbl, hb);
		bp.setTop(vb);
		
		setText("Prizes");
		setContent(bp);
	}
}
