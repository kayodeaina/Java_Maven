package application;
/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Apllication
 *  Semester 2, (Second Yr)
 */
import java.util.ArrayList;
import java.util.Collections;
import application.AlertBox;
import application.ConfirmBox;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;

public class lotto_Cure extends Tab{


//*******************************************************
//     Global variable
//*******************************************************	

	int noOfVictory = 0;
	int win = 0;

//*******************************************************
//        close window take value from another class
//*******************************************************		
	private void closeProgram(){
		Boolean result = ConfirmBox.display("Title", "Are you Sure you want to close");
		if(result)Platform.exit();}

//*******************************************************
//        national lottery class default constructor
//*******************************************************	
	public lotto_Cure() {

		setText("Lotto_Cure");

//*******************************************************
//      Layout Panes class gridPane object
//*******************************************************

		BorderPane bp = new BorderPane();
		GridPane grip = new GridPane();
		
			grip.setAlignment(Pos.CENTER);
			grip.setHgap(60);
			grip.setVgap(30);
			grip.setPadding(new Insets(0, 50,0 ,50));
//*******************************************************
//      second gridPane class & attribute setting.
//*******************************************************
		GridPane grip2 = new GridPane();
		
		grip2.setAlignment(Pos.CENTER);
		grip2.setHgap(60);
		grip2.setVgap(30);
		grip2.setPadding(new Insets(0, 50,0 ,50));
//*******************************************************
//      instruction of where to type
//*******************************************************		
		Label label = new Label();
		
		label.setStyle("-fx-font-size: 35pt;");
		label.setText("Welcome to Lotto cure");
		label.setTextFill(Color.web("#800000"));
		BorderPane.setAlignment(label, Pos.TOP_CENTER);
		grip2.add(label, 0, 0);
		
		Label label2 = new Label("Please type your guessing number inside each box");
		label2.setStyle("-fx-font-size: 15pt;");
	
		grip2.add(label2, 0, 1);
		bp.setTop(grip2);

		
//*******************************************************
//      ArrayList object
//*******************************************************



		ArrayList<Integer> myList = new ArrayList<Integer>();

		TextField txtfd_1 = new TextField();
		TextField txtfd_2 = new TextField();
		TextField txtfd_3 = new TextField();
		TextField txtfd_4 = new TextField();
		TextField txtfd_5 = new TextField();
		TextField txtfd_6 = new TextField();

//*******************************************************
//      Quit Button
//*******************************************************

		Button btnQuit = new Button("Quit");
		btnQuit.setStyle("-fx-font-size: 14pt;");
		btnQuit.setOnAction(e -> closeProgram());

//*******************************************************
//      Play Button
//*******************************************************

		Button btnPlayGame = new Button("Play");
		btnPlayGame.setStyle("-fx-font-size: 15pt;");

//*******************************************************
//      ArrayList Generating Random Numbers from 1 to 50
//*******************************************************

		ArrayList<Integer> myRandomList = new ArrayList<Integer>();
		for (int i=1; i<50; i++) 
		  { 
			myRandomList.add(new Integer(i));
		  
		  }

		Collections.shuffle(myRandomList);
			for (int i=0; i<6; i++)
			   {
				System.out.print(myRandomList.get(i) + " ");
				}

		//*******************************************************
		//      Event Handler for Submit Button
		//*******************************************************

		btnPlayGame.setOnAction(new EventHandler<ActionEvent>() {
		
			@Override
			public void handle(ActionEvent event) {
				
				try {
					Integer num1 = Integer.valueOf(txtfd_1.getText());
						myList.add(num1);

					Integer num2 = Integer.valueOf(txtfd_2.getText());
						myList.add(num2);

				    Integer num3 = Integer.valueOf(txtfd_3.getText());
				    	myList.add(num3);

				    Integer num4 = Integer.valueOf(txtfd_4.getText());
				    	myList.add(num4);

				    Integer num5 = Integer.valueOf(txtfd_5.getText());
				    	myList.add(num5);

				    Integer num6 = Integer.valueOf(txtfd_6.getText());
				    	myList.add(num6);
				}
				catch(Exception e)
				{
					AlertBox.display("Error", "Please Enter Number!");
				}

//*******************************************************
//		      Comparing random numbers & guessing number
//*******************************************************

				for(int i = 0; i < 6; i++)
				{
					//System.out.println(list.get(i));
					for(int n = 0; n < 6; n++) {
						//System.out.println(randomList.get(n));

					if (myList.get(i) < 1 || myList.get(i) > 49)
						{
							AlertBox.display("Incorrect Number", "Incorrect Number!");
						}
						
					else if(myList.get(i).equals(myRandomList.get(n)))
						{
							noOfVictory++;
						}
					}
				}

				if(noOfVictory >= 4) {
					Guessing_game.WinningPrize = noOfVictory;
					WinningAlertBox.display("Congrats", "You got " + noOfVictory, Guessing_game.WinningPrize);
					MainProgram.setDisable();
					MainProgram.setEnable();
				}
				else {
					AlertBox.display("Unlucky", "You got " + noOfVictory);
				}

			}
		});
//************************************************************************
//       Reset all text field to null
//************************************************************************		

		Button btnReset = new Button("Reset");
		btnReset.setStyle("-fx-font-size: 15pt;");
		btnReset.setOnAction(e ->{

			txtfd_1.setText("");
			txtfd_2.setText("");
			txtfd_3.setText("");
			txtfd_4.setText("");
			txtfd_5.setText("");
			txtfd_6.setText("");

		});
//*********************************************************
//		creating vertical box class and initialise
//      add all text field		
//*********************************************************		
		VBox myVb = new VBox();

		grip.getChildren().add(txtfd_1);
		grip.getChildren().add(txtfd_2);
		grip.getChildren().add(txtfd_3);
		grip.getChildren().add(txtfd_4);

		grip.getChildren().add(txtfd_5);
		grip.getChildren().add(txtfd_6);
		
		myVb.getChildren().addAll(txtfd_1,txtfd_2,txtfd_3,txtfd_4,txtfd_5,txtfd_6); 
		

//**************************************************************
//		adding all text to the grid rows & columns
//**************************************************************		
		
		grip.add(txtfd_1, 1,1);
		grip.add(txtfd_2, 2,1);
		grip.add(txtfd_3, 3,1);
		grip.add(txtfd_4, 4,1);
		grip.add(txtfd_5, 5,1);
		grip.add(txtfd_6, 6,1);
		grip.add(btnQuit, 2, 2);
		grip.add(btnPlayGame, 3, 2);
		grip.add(btnReset, 4, 2);
		
		
		grip.setAlignment(Pos.CENTER);
		BorderPane.setAlignment(grip, Pos.TOP_CENTER);
		bp.setCenter(grip);
			
		//grip.setGridLinesVisible(true);
		setContent(bp);
	}


}