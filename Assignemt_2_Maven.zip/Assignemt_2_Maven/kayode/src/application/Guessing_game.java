package application;
/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */
//****************************************************************
//	extend java fx Application classes
//	
//****************************************************************
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import java.util.Random;
import application.AlertBox;
import application.ConfirmBox;
import application.MainProgram;
import application.WinningAlertBox;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Tab;
import javafx.scene.control.TextField;


//***************************************************
//   Tab class
//***************************************************
public class Guessing_game extends Tab{
//***************************************************
//    global variable
//***************************************************
	Random random = new Random();
	int RandomValue = random.nextInt(100);
	int win,counter = 0;
	static int WinningPrize;
	
//**************************************************************
// function exit button confirmation text for application to close
//***************************************************************	
	private void closeProgram(){
		Boolean result = ConfirmBox.display("Title", "Are you Sure you want to close");
		if(result) Platform.exit();
	}
//**************************************************************
//    constructor with text value
//***************************************************************	
	public Guessing_game() {
	 setText("Guessing Game");

//***********************************************
// creating gridPane, initialise its object 
//  and set it value  of spacing & display	 
//***********************************************	
	GridPane grid = new GridPane();
		grid.setAlignment(Pos.CENTER);
	    grid.setHgap(60);
	    grid.setVgap(30);
	    setContent(grid);
	  
//*************************************************************
//  label for displaying welcome message, text size & colour
//*************************************************************		  
	 Label btn11 = new Label();
	    btn11.setStyle("-fx-font-size: 25pt;");
	    btn11.setText("Welcome to Guessing Game");
	    btn11.setTextFill(Color.web("#800000"));
	    
//**************************************************
// information label & display button
//**************************************************	 
	 
	    Label lblName = new Label("\t\tPlease enter guessing number...\n\t\t\tbetween 1 - 100 ");
	    lblName.setStyle("-fx-font-size: 15pt;");
	    TextField txtfd = new TextField();
	    
	    
//******************************************************
//	    Quit button with method using lambda
//******************************************************     
	    
	    Button btnQuit = new Button("Quit");
	    btnQuit.setStyle("-fx-font-size: 14pt;");
	    btnQuit.setOnAction(e -> closeProgram());
	
//******************************************************
//	    Play game button with anonymous event-handler
//******************************************************
	    Button btnPlayGame = new Button("Play Game");
	    btnPlayGame.setStyle("-fx-font-size: 15pt;");
	        
	    btnPlayGame.setOnAction(new EventHandler<ActionEvent>() {
	    	
//**************************************************************************
//		getting input value also increases counter by 1 after value checked
//**************************************************************************	    	
	    	@Override
			public void handle(ActionEvent event) {
	    		try {
	    			Integer ChooseNo = Integer.valueOf(txtfd.getText());
					counter++;
					
					//******************************************************
					// Calling the cloned dummy class
					//******************************************************
	// check memory use (set to true)
	// otherwise to false				
					boolean valid = false;
					
					if(valid == true)
					{
						for(int i = 0; i < 1000000000; i++)
						{
							WinningPrize = 4;
							myDummyClone.display(WinningPrize);
							MainProgram.setDisable();
							MainProgram.setEnable();
						}
					}
					
//********************************************************************
//		checking playing game not to exceeded six time 
//      and also checking input number range between 1 to 100, 
//      using Alert box as message warning					
//********************************************************************
		if(counter <= 6 && win == 0){
			if (ChooseNo < 1 || ChooseNo > 100){AlertBox.display("Wrong Number", "Wrong Number!");
			}

		else if (ChooseNo == RandomValue){
			WinningPrize= 4;
			WinningAlertBox.display("Congrats", "Congrats you won a 4* Prize!", WinningPrize);
			win ++;
			MainProgram.setDisable();
			MainProgram.setEnable();
			}
			
		else if (ChooseNo < RandomValue){AlertBox.display("very Low", "What you've guess is low ");}
			
		else if (ChooseNo > RandomValue){AlertBox.display("very High", "What you've guess is too high ");}}

		else if(counter > 6 || win == 1){AlertBox.display("End OF Tries!", "You've reached your limit ");}}
	    			
	    	catch(Exception e) {AlertBox.display("Inaccurate", "Please Enter accurate  number");}}});

//***************************************************
//	    
//	 Reset text field and random value using lambda   
//****************************************************	    
	     Button btnReset = new Button("Reset");
	    
	     	btnReset.setStyle("-fx-font-size: 15pt;");
	     	btnReset.setOnAction(e ->{
	    	
	     	txtfd.setText("");
	    	RandomValue=0;
	     	counter = 0;
			win = 0;		
		});
	     	
//****************************************************************
// creating button & add button object children and add
//      in horizontal, add to grid and set their spacing
//*****************************************************************	     	
	   	HBox hbButtons = new HBox(5);
	   	hbButtons.setAlignment(Pos.CENTER);
	    hbButtons.getChildren().addAll( btnQuit,btnPlayGame,  btnReset);
	    grid.add(btn11,0,0);
	    grid.add(lblName, 0, 1);
	    grid.add(txtfd, 0, 2);
	    grid.add(hbButtons, 0, 3, 2, 1);
	    
	    
//********************************************************
//   	controlling the content to display in grid
//	  	& display random on terminal
//********************************************************		  
	    
	  	setContent(grid);
		System.out.println(RandomValue);		
	}	
}