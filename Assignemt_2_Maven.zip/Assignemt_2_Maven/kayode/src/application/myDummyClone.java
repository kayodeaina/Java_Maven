package application;
/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class myDummyClone   {
	
	//*********************************************
	// Create a bunch of dummy objects
	//*********************************************

	public static void display(int Winningprize) {

		String firstName;
		String lastName;

		firstName = "Kayode";
		lastName = "Aina";
		
		myWinners winners = new myWinners(firstName, lastName, Winningprize);
		myWinners.add(winners);

		try {
			FileOutputStream fileOut =
			 new FileOutputStream("C:/Users/kayod/eclipse-workspace/kayode/winners.ser");
			ObjectOutputStream output = new ObjectOutputStream(fileOut);
			output.writeObject(winners);
			output.close();
			fileOut.close();
			System.out.println("Serialized data is saved into C:/Users/kayod/eclipse-workspace/kayode/winners.ser");
		} catch (IOException i) {
			i.printStackTrace();
		}
	}
}