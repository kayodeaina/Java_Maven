package application;

/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;

public class myWinners extends Tab implements java.io.Serializable {

	//**********************************************************
	//	Declaring the global variables
	//**********************************************************

	private static final long serialVersionUID = 1L;
	public String firstN;
	public String lastN;
	public int WinningPrize;
	
	//**********************************************************
	// We make these variable transient as we don't want to 
	// implement these as serializable
	//**********************************************************

	transient static int numWinners = 0;
	transient static ArrayList<myWinners> myWinners = new ArrayList<myWinners>();
	
	//*************************************************************
	//	Get the values of the winners and add then to an arraylist
	//*************************************************************

	public myWinners(String first, String last, int prize)
	{		
		this.firstN = first;
		this.lastN = last;
		this.WinningPrize = prize;
	}

	public static void add(myWinners w) 
	{
		myWinners.add(w);
		numWinners ++;
	}

	private void closeProgram(){
		Boolean answer = ConfirmBox.display("Title", "Are you Sure you want to close");
		if(answer)
			Platform.exit();
	}

	public String toString(){ 
		return firstN + " " + lastN + " " + WinningPrize + "\n";
	}
	
	//**********************************************************
	//	This orders the winners list by name
	//**********************************************************

	public transient Comparator<myWinners> NameComparator = new Comparator<myWinners>() {

		@Override
		public int compare(myWinners firstWinner, myWinners secondWinner) {
			int lastCmp = firstWinner.lastN.toUpperCase().compareTo(secondWinner.lastN.toUpperCase());
			return (lastCmp != 0 ? lastCmp : firstWinner.firstN.toUpperCase().compareTo(secondWinner.firstN.toUpperCase()));	        
			}
		};
		
		//**********************************************************
		//	 Orders the winners list by prize
		//**********************************************************

		public transient Comparator<myWinners> PrizeComparator = new Comparator<myWinners>() {

			public int compare(myWinners firstWinner, myWinners secondWinner) {

				int prize_1 = firstWinner.WinningPrize;
				int prize_2 = secondWinner.WinningPrize;

				//For ascending order
				return prize_1-prize_2;
				}
			};

			public myWinners() {
				
				//**********************************************************
				// Adding all the contents to a border layout 	
				//**********************************************************
				
				setText("Winners");

				BorderPane border = new BorderPane();
				VBox vbox = new VBox(5);
				HBox hbox = new HBox(5);

				Label title = new Label("Welcome to the Winners Menu ");
			    title.setStyle("-fx-font-size: 25pt;");
			    title.setTextFill(Color.web("#800000"));
				BorderPane.setAlignment(title, Pos.CENTER);
				border.setTop(title);

				Label lbl = new Label("\nList of Winners ordered by name");
				lbl.setFont(new Font("Arial", 15));
				vbox.getChildren().add(lbl);
				
				//**********************************************************
				// Displays the winners list sorted by name
				//**********************************************************

				Collections.sort(myWinners, NameComparator);

				String names = myWinners.toString()
						.replace(",", "")
						.replace("[", "")
						.replace("]", "");

				Label label = new Label(names);
				vbox.getChildren().add(label);

				Label lbl1 = new Label("\nList of Winners ordered by prize");
				lbl1.setFont(new Font("Arial", 15));
				vbox.getChildren().add(lbl1);
				
				//**********************************************************
				// Displays the winners list by prize
				//**********************************************************

				Collections.sort(myWinners, PrizeComparator);
				
				String names1 = myWinners.toString()
						.replace(",", "")
						.replace("[", "")
						.replace("]", "");
				Label label1 = new Label(names1);
				vbox.getChildren().add(label1);
				BorderPane.setMargin(vbox, new Insets(10));


				Button Remove = new Button ("Remove");
				Remove.setOnAction((ActionEvent event) ->{

					WinningAlertBox.display("Remove", "Enter details of person you want to remove!", 1);
				});

				Button Quit = new Button ("Quit");
				Quit.setOnAction(e -> closeProgram());
				hbox.getChildren().addAll(Remove, Quit);
				vbox.getChildren().add(hbox);
				BorderPane.setMargin(hbox, new Insets(10));
				border.setLeft(vbox);

				setContent(border);
			}
			
			//**********************************************************
			// Deserialize the contents in the file and display them
			//**********************************************************

			public static void main(String [] args) {
				myWinners winners = null;

				try {
					FileInputStream fileIn = new FileInputStream("C:/Users/kayod/eclipse-workspace/kayode/winners.ser");
					ObjectInputStream input = new ObjectInputStream(fileIn);
					winners = (myWinners) input.readObject();
					input.close();
					fileIn.close();
				} catch (IOException i) {
					i.printStackTrace();
					return;
				} catch (ClassNotFoundException c) {
					System.out.println("Employee class not found");
					c.printStackTrace();
					return;
				}

				System.out.println("Deserialized the Winners...");
				System.out.println("First Name: " + winners.firstN);
				System.out.println("Last Name: " + winners.lastN);
				System.out.println("Prize: " + winners.WinningPrize);
			}

}