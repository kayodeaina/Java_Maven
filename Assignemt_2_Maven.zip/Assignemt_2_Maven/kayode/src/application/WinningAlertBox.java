package application;

/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */
import javafx.stage.*;

import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.control.*;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.*;

public class WinningAlertBox   {

	public static void display(String title, String message, int prize) {
		Stage window = new Stage();
		VBox vb = new VBox(10);
		
		//Block events to other windows
		window.initModality(Modality.APPLICATION_MODAL);
		window.setTitle(title);
		window.setMinWidth(300);
		window.setMinHeight(100);

		Label label = new Label();
		label.setText(message);

		Label label1 = new Label();
		label1.setText("First name: ");

		TextField first = new TextField();

		Label label2 = new Label();
		label2.setText("Last name: ");

		TextField last = new TextField();
		
		vb.getChildren().addAll(label, label1, first, label2, last);
		
		//****************************************************************
		// if title equals Congratulations then we can add the person to
		// the winners list
		//****************************************************************
		
		if(title.equals("Congrats"))
		{
				
		Button enterButton = new Button("Enter");
		
		vb.getChildren().add(enterButton);

		enterButton.setOnAction(new EventHandler<ActionEvent>() {

			@Override
			public void handle(ActionEvent event) {
				
				String firstName = first.getText();
				String lastName = last.getText();
				
				myWinners winners = new myWinners(firstName, lastName, prize);
				myWinners.add(winners);
		
				//********************************************************************
				// Adding the contents to a serializable file with destination folder
				//********************************************************************
				try {
			         FileOutputStream fileOut =
			         new FileOutputStream("C:/Users/kayod/eclipse-workspace/kayode/winners.ser");
			         ObjectOutputStream output = new ObjectOutputStream(fileOut);
			         output.writeObject(winners);
			         output.close();
			         fileOut.close();
			         System.out.print("\nSerialized data is saved into C:/Users/kayod/eclipse-workspace/kayode/winners.ser");
			      } catch (IOException i) {
			         i.printStackTrace();
			      }

				window.close();

			}      
		});
		
		}
		
		//**************************************************************
		//while title equals remove then and display the prompt which
		// asks the user the person they want to remove from the list.
		//**************************************************************
		
		else if(title.equals("Remove"))
		{
			Button remove = new Button("Remove");
			vb.getChildren().add(remove);

			remove.setOnAction(new EventHandler<ActionEvent>() {

				@Override
				public void handle(ActionEvent event) {
					
					String firstName = first.getText();
					String lastName = last.getText();
					
					for(int i = 0; i < myWinners.numWinners; i++)
					{
				if(firstName.equalsIgnoreCase(myWinners.myWinners.get(i).firstN) 
				 && lastName.equalsIgnoreCase(myWinners.myWinners.get(i).lastN))                       
						
				{
					AlertBox.display("Remove", myWinners.myWinners.get(i).firstN + " has been removed from list");
					myWinners.myWinners.remove(i);
					myWinners.numWinners --;
					MainProgram.setDisable();
					MainProgram.setEnable();
				}
						
				else{
						AlertBox.display("Mistake", "Name can't be found");
					}
				  }	

					window.close();
				}      
			});
		  }

		//Display window and wait for it to be closed before return.
		vb.setAlignment(Pos.CENTER);
	
		Scene scene = new Scene(vb,300,500);
		scene.setFill(Color.BISQUE);
		window.setScene(scene);
		window.showAndWait();
	}

}