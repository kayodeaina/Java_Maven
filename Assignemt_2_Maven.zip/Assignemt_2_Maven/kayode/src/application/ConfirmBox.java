/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */
package application;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.scene.layout.*;

public class ConfirmBox {
	
//**********************************************************	
//    Create variable & iniModality that will prevent pop-window
//    to be close until action it taken first	
//**********************************************************	
    static boolean result;

    public static boolean display(String myTitle, String myMessage) {
        Stage window = new Stage();
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(myTitle);
        window.setMinWidth(250);
        Label label = new Label();
        label.setText(myMessage);
//*****************************************************************
//         Buttons that serve and change of mind
//*****************************************************************        
        Button myYesButton = new Button("Sure ");
        Button myNoButton = new Button("Cancel");

//*****************************************************
//    option  button calling on action using lambda 
//        to close the window
//*****************************************************
        myYesButton.setOnAction(e -> {
            result = true;
            window.close();
        });
        myNoButton.setOnAction(e -> {
            result = false;
            window.close();
        });

        VBox vb = new VBox(22);
//*********************************************************
//        Add buttons to layout
//********************************************************        
        vb.getChildren().addAll(label, myYesButton, myNoButton);
        vb.setAlignment(Pos.CENTER);
        Scene scene = new Scene(vb);
        window.setScene(scene);
        window.showAndWait();

//******************************************************************
//              Make sure to return answer
//*****************************************************************s        
        return result;
    }

}