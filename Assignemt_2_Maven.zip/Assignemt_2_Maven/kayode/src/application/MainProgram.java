package application;
/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */

import application.prize;

//*************************************************************
//	importing all needed packages
//**************************************************************

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

//****************************************************************
//	extend java fx application class &
//	declaring TabPane & initialise it, and launch all application
//****************************************************************


public class MainProgram extends Application{
	
	static myWinners myWinners = new myWinners();
	static prize prize = new prize();

	static TabPane tp = new TabPane();
	public static void main(String[] args) {
		launch(args);
	}
//************************************************************
//   try catch what could disturb programming flow and error
//************************************************************	
	@Override
	public void start(Stage primaryStage) {
		try {
			BorderPane mainPane = new BorderPane();
			Group root = new Group();
			Scene scene = new Scene(root,1000,800);

//***********************************************************
//       adding Tab object as new tab (name)
//**********************************************************			
			
			tp.getTabs().add(new Guessing_game());
			tp.getTabs().add(new lotto_Cure());
			
		
//***********************************************************
//	       setting spacing, height and width
//**********************************************************			
			mainPane.setCenter(tp);
			mainPane.prefHeightProperty().bind(scene.heightProperty());
			mainPane.prefWidthProperty().bind(scene.widthProperty());
			
	
			root.getChildren().add(mainPane);
			primaryStage.setScene(scene);
			primaryStage.show();
			scene.setFill(Color.BISQUE);
			
	
		} catch(Exception e) {
			e.printStackTrace();
		}
}

//*******************************************************
//  declaring static method & accessing Tab object with
//	as prize tab and set to Disable.
//*******************************************************
	public static void setEnable(){
		
		myWinners = new myWinners();
		prize = new prize();
				
		tp.getTabs().add(prize);
		tp.getTabs().add(myWinners);
	}
	
	public static void setDisable(){
		
		tp.getTabs().remove(prize);
		tp.getTabs().remove(myWinners);
	}

}
