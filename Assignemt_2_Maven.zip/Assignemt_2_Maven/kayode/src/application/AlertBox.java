/*
 *  Student Name: kayode-Aina
 *  Student ID: R00142858
 * 	Tutor Name: Dr Denis - Long
 * 	Javafx Application
 *  Semester 2, (Second Year)
 */

package application;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.geometry.*;
import javafx.stage.*;
import javafx.scene.*;


public class AlertBox {

public static void display(String mytitle, String myMessage) {
        Stage window = new Stage();
        
//************************************************************        
//    Block events to other windows & prompt for action
//************************************************************        
        window.initModality(Modality.APPLICATION_MODAL);
        window.setTitle(mytitle);
        window.setMinWidth(500);

        Label mylbl = new Label();
        mylbl.setText(myMessage);
        Button closeBtn = new Button("Window_Exit");
        closeBtn.setOnAction(e -> window.close());
//********************************************************************
//       Alert box window to centre and size of the label
//********************************************************************        
        VBox vb = new VBox(25);
        vb.getChildren().addAll(mylbl, closeBtn);
        vb.setAlignment(Pos.CENTER);
//****************************************************************
//
//   Display window and wait for it to be closed before returning
//     Scene        
//******************************************************************        
        Scene scene = new Scene(vb);
        window.setScene(scene);
        window.showAndWait();
        
        }
}
